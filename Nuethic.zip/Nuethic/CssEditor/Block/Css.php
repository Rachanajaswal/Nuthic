<?php

namespace Nuethic\CssEditor\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\UrlInterface;

class Css extends Template
{
	/**
     * @param Template\Context $context
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        
    }

    public function getCssPath()
    {
        return $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]).'css-editor.css';
    }
}