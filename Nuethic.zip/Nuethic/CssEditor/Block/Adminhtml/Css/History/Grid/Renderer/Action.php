<?php

namespace Nuethic\CssEditor\Block\Adminhtml\Css\History\Grid\Renderer;

class Action extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\Action
{
    /**
     * Renderer for "Action" column in Newsletter templates grid
     *
     * @param \Magento\Framework\DataObject $row
     * @return string
     */
    public function render(\Magento\Framework\DataObject $row)
    {
        $actions[] = [
                'url' => $this->getUrl('csseditor/csseditor/rollback', ['history_id' => $row->getId()]),
                'caption' => __('Rollback This'),
                'confirm' => 'Are you sure you want to rollback this version?'
            ];
        //echo "<pre>";print_r(get_class_methods($this->getColumn()));exit;    
        $this->getColumn()->setActions($actions);

        return parent::render($row);
    }
}
