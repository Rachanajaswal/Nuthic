<?php

namespace Nuethic\CssEditor\Block\Adminhtml\Css\Tab;

use Magento\Backend\Block\Widget\Grid;
use Magento\Backend\Block\Widget\Grid\Column;
use Magento\Backend\Block\Widget\Grid\Extended;
use Magento\Framework\App\ObjectManager;

class History extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var \Nuethic\CssEditor\Model\History
     */
    protected $_historyFactory;


    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Nuethic\CssEditor\Model\HistoryFactory $historyFactory
     * @param \Magento\Framework\Registry $coreRegistry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Nuethic\CssEditor\Model\HistoryFactory $historyFactory,
        \Magento\Framework\Registry $coreRegistry,
        array $data = []        
    ) {
        $this->_historyFactory = $historyFactory;
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('css_history');
        $this->setDefaultSort('history_id');
        $this->setUseAjax(true);
    }

    /**
     * @return array|null
     */
    public function getCssIndex()
    {
        return $this->_coreRegistry->registry('css');
    }

    /**
     * @return Grid
     */
    protected function _prepareCollection()
    {
        
        if ($this->getCssIndex()->getId()) {
            $collection = $this->_historyFactory->create()->getCollection();
            $collection->addFieldToFilter('css_id', ['eq'=>$this->getCssIndex()->getId()]);
            $this->setCollection($collection);
        }
        return parent::_prepareCollection();
    }

    /**
     * @return Extended
     */
    protected function _prepareColumns()
    {
       
        $this->addColumn(
            'history_id',
            [
                'header' => __('Version No.'),
                'sortable' => true,
                'index' => 'history_id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        );
        $this->addColumn(
            'updated_at', 
            [
                'header' => __('Created At'), 
                'index' => 'updated_at',
                'gmtoffset' => true,
                'type' => 'datetime',
            ]
        );

        $this->addColumn(
            'action',
            [
                'header' => __('Rollback'),
                'index' => 'history_id',
                'sortable' => false,
                'filter' => false,
                'no_link' => true,
                'renderer' => \Nuethic\CssEditor\Block\Adminhtml\Css\History\Grid\Renderer\Action::class,
                'header_css_class' => 'col-actions',
                'column_css_class' => 'col-actions'
            ]
        );
        return parent::_prepareColumns();
    }

    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('csseditor/*/grid', ['_current' => true]);
    }
}
