<?php


namespace Nuethic\CssEditor\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;


/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {

        $installer = $setup;
        $installer->startSetup();

        /*
         * Create table 'nuethic_css_index'
         */
        $table = $installer->getConnection()
            ->newTable($installer->getTable('nuethic_css_index'))
            ->addColumn(
                'css_id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Css Index Id'
            )
            ->addColumn(
                'css_name',
                Table::TYPE_TEXT,
                45,
                ['nullable' => false],
                'Css Name'
            )
            ->addColumn(
                'load_order',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => false, 'unsigned' => true],
                'Css Load Order'
            ) 
            ->addColumn(
                'active_css',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => false, 'unsigned' => true],
                'Active Css Version'
            )  
            ->addColumn(
                'is_enabled',
                Table::TYPE_SMALLINT,
                null,
                ['nullable' => false, 'default' => '1'],
                'Is Css Enabled'
            )                       
            ->setComment('Css Index');
        $installer->getConnection()->createTable($table);


        /*
         * Create table 'nuethic_css_history'
         */
        $table = $installer->getConnection()
            ->newTable($installer->getTable('nuethic_css_history'))
            ->addColumn(
                'history_id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Css History Id'
            )
            ->addColumn(
                'css_id',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => false,'unsigned' => true],
                'Css Index'
            )            
            ->addColumn(
                'user_id',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Created by User'
            )
            ->addColumn(
                'css',
                Table::TYPE_TEXT,
                null,
                ['nullable' => false],
                'Css'
            )
            ->addColumn(
                'updated_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE],
                'Last updated date'
            )                 
            ->addForeignKey(
                $installer->getFkName(
                    'nuethic_css_history',
                    'css_id',
                    'nuethic_css_index',
                    'css_id'
                ),
                'css_id',
                $installer->getTable('nuethic_css_index'),
                'css_id',
                Table::ACTION_CASCADE
            )
            ->addForeignKey(
                $installer->getFkName(
                    'nuethic_css_history',
                    'user_id',
                    'admin_user',
                    'user_id'
                ),
                'user_id',
                $installer->getTable('admin_user'),
                'user_id',
                Table::ACTION_NO_ACTION
            )     
            ->setComment('Css History');
        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }
}