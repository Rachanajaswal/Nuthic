<?php

namespace Nuethic\CssEditor\Model;

class Css extends \Magento\Framework\Model\AbstractModel
{

    protected $_eventPrefix = 'csseditor_css';

    /**#@+
     * CSS's Statuses
     */
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 0;
    
    /**
    * Constructor
    *
    * @param \Magento\Framework\Model\Context $context,
    * @param \Magento\Framework\Registry $registry,
    * @param \Nuethic\CssEditor\Model\ResourceModel\Css $resource,
    * @param \Nuethic\CssEditor\Model\ResourceModel\Css\Collection $collection,
    * @param array $data = []
    */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Nuethic\CssEditor\Model\ResourceModel\Css $resource,
        \Nuethic\CssEditor\Model\ResourceModel\Css\Collection $collection,
        \Nuethic\CssEditor\Model\HistoryFactory $historyFactory,
        array $data = []
    ) {
        $this->historyFactory = $historyFactory;
         parent::__construct($context,$registry,$resource,$collection,$data);
    }

    /**
    * Initialization
    *
     *@return void
    */
    protected function _construct()
    {
        $this->_init(\Nuethic\CssEditor\Model\ResourceModel\Css::class);
    }

    protected function _afterLoad()
    {
        $histories = $this->historyFactory->create()->getCollection();
        $histories->addFieldToFilter('css_id',['eq'=>$this->getActiveCss()]);
        if($histories->count())
        {
            $this->setCss($histories->getFirstItem()->getCss());    
        }
        parent::_afterLoad();
    }
}