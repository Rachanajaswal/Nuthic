<?php

namespace Nuethic\CssEditor\Model\Css;

use Nuethic\CssEditor\Model\ResourceModel\Css\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;


/**
 * Class DataProvider
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var \Magento\Cms\Model\ResourceModel\Block\Collection
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * Constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $blockCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $blockCollectionFactory,
        DataPersistorInterface $dataPersistor,
        \Nuethic\CssEditor\Model\HistoryFactory $historyFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $blockCollectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->historyFactory = $historyFactory;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        
        foreach ($items as $css) {
            $histories = $this->historyFactory->create()->getCollection();
            $histories->addFieldToFilter('history_id',['eq'=>$css->getActiveCss()]);
            $css->setCss($histories->getFirstItem()->getCss());
            $this->loadedData[$css->getId()] = $css->getData();
            
        }

        $data = $this->dataPersistor->get('css');
        if (!empty($data)) {
            $css = $this->collection->getNewEmptyItem();
            $css->setData($data);
            $this->loadedData[$block->getId()] = $css->getData();
            $this->dataPersistor->clear('css');
        }

        return $this->loadedData;
    }
}
