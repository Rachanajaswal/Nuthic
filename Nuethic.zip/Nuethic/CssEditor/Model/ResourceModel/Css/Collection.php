<?php

namespace Nuethic\CssEditor\Model\ResourceModel\Css;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName='css_id';
    /**
    * Initialize resource
    *
    * @return void
    */
    protected function _construct()
    {
        $this->_init(\Nuethic\CssEditor\Model\Css::class, \Nuethic\CssEditor\Model\ResourceModel\Css::class);
    }
}