<?php

namespace Nuethic\CssEditor\Model\ResourceModel\History;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName='history_id';
    /**
    * Initialize resource
    *
    * @return void
    */
    protected function _construct()
    {
        $this->_init(\Nuethic\CssEditor\Model\History::class, \Nuethic\CssEditor\Model\ResourceModel\History::class);
    }
}