<?php

namespace Nuethic\CssEditor\Model\ResourceModel;

class Css extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	/**
	* Constructor
	*
	* @param \Magento\Framework\Model\ResourceModel\Db\Context $context,
	* @param string $connectionName
	*/
	public function __construct(
		\Magento\Framework\Model\ResourceModel\Db\Context $context,
		$connectionName = null
	) {
		 parent::__construct($context,$connectionName);
	}

	/**
	* Define Main Table
	*
	* @return void
	*/
	protected function _construct()
	{
		$this->_init('nuethic_css_index','css_id');
	}
}