<?php

namespace Nuethic\CssEditor\Model;

class History extends \Magento\Framework\Model\AbstractModel
{

   
    /**
    * Constructor
    *
    * @param \Magento\Framework\Model\Context $context,
    * @param \Magento\Framework\Registry $registry,
    * @param \Nuethic\CssEditor\Model\ResourceModel\History $resource,
    * @param \Nuethic\CssEditor\Model\ResourceModel\History\Collection $collection,
    * @param array $data = []
    */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Nuethic\CssEditor\Model\ResourceModel\History $resource,
        \Nuethic\CssEditor\Model\ResourceModel\History\Collection $collection,
        array $data = []
    ) {
         parent::__construct($context,$registry,$resource,$collection,$data);
    }

    /**
    * Initialization
    *
     *@return void
    */
    protected function _construct()
    {
        $this->_init(\Nuethic\CssEditor\Model\ResourceModel\History::class);
    }

}