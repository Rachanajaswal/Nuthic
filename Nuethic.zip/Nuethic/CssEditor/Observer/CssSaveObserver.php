<?php

namespace Nuethic\CssEditor\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class CssSaveObserver implements ObserverInterface
{
	 /**
     * @param \Nuethic\CssEditor\Model\CssFactory $cssFactory
     * @param \Nuethic\CssEditor\Model\HistoryFactory $historyFactory
     */
    public function __construct(
    	\Nuethic\CssEditor\Model\CssFactory $cssFactory,
    	\Nuethic\CssEditor\Model\HistoryFactory $historyFactory,
    	\Magento\Framework\App\Filesystem\DirectoryList $directoryList
    )
    {
    	$this->cssFactory = $cssFactory;
    	$this->directoryList = $directoryList;
    	$this->historyFactory = $historyFactory;
    }

	/**
     * Check captcha on user login page
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
    	$css='';
    	$collection = $this->cssFactory->create()->getCollection();
        $collection->setOrder('load_order','ASC');
    	foreach($collection as $cssIndex)
    	{
    		$history = $this->historyFactory->create();
    		$history->load($cssIndex->getActiveCss());
    		$css.=$history->getCss();
    	}

    	$targetPath = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
    	$filePath = $targetPath.'/css-editor.css'; 
    	$handle = fopen($filePath, "w");
    	fwrite($handle, $css);
        fputcsv($handle,$labels);
        fclose($handle);
    	return $this; 
    }
}