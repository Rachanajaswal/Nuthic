<?php

namespace Nuethic\CssEditor\Controller\Adminhtml\CssEditor;

use Magento\Backend\App\Action;
use Nuethic\CssEditor\Model\Css;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;

class Rollback extends \Magento\Backend\App\Action 
{
/**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Nuethic_CssEditor::css_save';

    /**
     * @var \Nuethic\CssEditor\Model\CssFactory
     */
    private $cssFactory;

    /**
     * @var \Nuethic\CssEditor\Model\historyFactory
     */
    private $historyFactory;

    /**
     * @param Action\Context $context
     * @param \Nuethic\CssEditor\Model\CssFactory $cssFactory
     * @param \Nuethic\CssEditor\Model\HistoryFactory $historyFactory
     */
    public function __construct(
        Action\Context $context,
        \Nuethic\CssEditor\Model\CssFactory $cssFactory,
        \Nuethic\CssEditor\Model\HistoryFactory $historyFactory
    ) {
        $this->cssFactory = $cssFactory;
        $this->historyFactory = $historyFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
    	$id = $this->getRequest()->getParam('history_id');
    	$resultRedirect = $this->resultRedirectFactory->create();


    	$history = $this->historyFactory->create()->load($id);
    	if(!$history->getId())
    	{
    		return $resultRedirect->setPath('*/*/index');
    	}
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        
        $cssIndex = $this->cssFactory->create();
        $cssIndex->load($history->getCssId());

        if ($cssIndex->getId()) 
        {
            try {
                $cssIndex->setActiveCss($history->getId());
                $cssIndex->save();
                $this->messageManager->addSuccessMessage(__('CSS has been rollback to selected version.'));
            } catch (LocalizedException $e) {
                $this->messageManager->addExceptionMessage($e->getPrevious() ?: $e);
                $this->dataPersistor->set('css', $data);
                return $resultRedirect->setPath('*/*/edit', ['css_id' => $cssIndex->getId()]);
            } catch (\Exception $e) {
            	echo $e->getMessage();exit;
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while rollback the CSS.'));
                return $resultRedirect->setPath('*/*/edit', ['css_id' => $cssIndex->getId()]);
            }   
        }
        return $resultRedirect->setPath('*/*/edit', ['css_id' => $cssIndex->getId()]);
    }
}