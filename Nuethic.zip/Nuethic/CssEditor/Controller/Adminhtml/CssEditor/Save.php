<?php

namespace Nuethic\CssEditor\Controller\Adminhtml\CssEditor;

use Magento\Backend\App\Action;
use Nuethic\CssEditor\Model\Css;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action 
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Nuethic_CssEditor::css_save';
 	

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var \Nuethic\CssEditor\Model\CssFactory
     */
    private $cssFactory;

    /**
     * @var \Nuethic\CssEditor\Model\historyFactory
     */
    private $historyFactory;

    /**
     * @param Action\Context $context
     * @param DataPersistorInterface $dataPersistor
     * @param \Nuethic\CssEditor\Model\CssFactory $cssFactory
     * @param \Nuethic\CssEditor\Model\HistoryFactory $historyFactory
     */
    public function __construct(
        Action\Context $context,
        DataPersistorInterface $dataPersistor,
        \Nuethic\CssEditor\Model\CssFactory $cssFactory,
        \Nuethic\CssEditor\Model\HistoryFactory $historyFactory
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->cssFactory = $cssFactory;
        $this->historyFactory = $historyFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) 
        {
            if (isset($data['is_enabled']) && $data['is_enabled']) {
                $data['is_enabled'] = Css::STATUS_ENABLED;
            }
            else{
                $data['is_enabled'] = Css::STATUS_DISABLED;
            }
            
            if (empty($data['css_id'])) {
                $data['css_id'] = null;
            }

            /** @var \Magento\Cms\Model\Page $model */
            $model = $this->cssFactory->create();
            
            $id = $this->getRequest()->getParam('css_id');
            if ($id) {
                $model->load($id);
                if(!$model->getId())
                {
                	$this->messageManager->addErrorMessage(__('This css no longer exists.'));
                	return $resultRedirect->setPath('*/*/');
                }
            }

            $model->setData($data);
            try {
                $model->save($model);
                $history = $this->historyFactory->create();
                $history->setCssId($model->getId());
                $history->setUserId($this->getUserId());
                $history->setCss($data['css']);
                $history->save();
                $model->setActiveCss($history->getId());
                $model->save();
                $this->messageManager->addSuccessMessage(__('You saved the CSS.'));
                $this->dataPersistor->clear('css');
                if ($this->getRequest()->getParam('back')=='continue') {
                    return $resultRedirect->setPath('*/*/edit', ['css_id' => $model->getId(), '_current' => true]);
                }
            } catch (LocalizedException $e) {
                $this->messageManager->addExceptionMessage($e->getPrevious() ?: $e);
                $this->dataPersistor->set('css', $data);
                return $resultRedirect->setPath('*/*/edit', ['css_id' => $this->getRequest()->getParam('css_id')]);
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the CSS.'));
                $this->dataPersistor->set('css', $data);
                return $resultRedirect->setPath('*/*/edit', ['css_id' => $this->getRequest()->getParam('css_id')]);
            }   
        }
        return $resultRedirect->setPath('*/*/');
    }

    protected function getUserId()
    {
        $user = $this->_auth->getUser();
        return $user->getId();
    }
}